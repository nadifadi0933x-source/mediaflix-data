package com.mediaflix.app.data.repository

import com.mediaflix.app.data.api.*
import com.mediaflix.app.data.db.BookmarkDao
import com.mediaflix.app.data.db.CustomLinkDao
import com.mediaflix.app.data.model.*
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MediaRepository @Inject constructor(
    private val tmdbApi: TmdbApi,
    private val jikanApi: JikanApi,
    private val aniListClient: AniListClient,
    private val mangaDexApi: MangaDexApi,
    private val shineiApi: ShineiApi,
    private val customLinkDao: CustomLinkDao,
    private val bookmarkDao: BookmarkDao
) {
    companion object {
        // TODO: Replace with your own TMDB API key from https://www.themoviedb.org/settings/api
        const val TMDB_API_KEY = "YOUR_TMDB_API_KEY"
        const val TMDB_IMAGE_BASE = "https://image.tmdb.org/t/p/"
        const val MANGADEX_COVER_BASE = "https://uploads.mangadex.org/covers/"
    }

    // ==================== TMDB — Movies & Series ====================

    suspend fun getTrending(page: Int = 1): List<MediaItem> {
        val response = tmdbApi.getTrending(TMDB_API_KEY, page = page)
        return response.results.map { it.toMediaItem() }
    }

    suspend fun getPopularMovies(page: Int = 1): List<MediaItem> {
        val response = tmdbApi.getPopularMovies(TMDB_API_KEY, page = page)
        return response.results.map { it.toMediaItem() }
    }

    suspend fun getPopularSeries(page: Int = 1): List<MediaItem> {
        val response = tmdbApi.getPopularSeries(TMDB_API_KEY, page = page)
        return response.results.map { it.toMediaItem() }
    }

    suspend fun getMovieDetail(movieId: Long): MediaItem {
        val movie = tmdbApi.getMovieDetail(movieId, TMDB_API_KEY)
        val link = customLinkDao.getLink("tmdb_movie_$movieId")
        return movie.toMediaItem().copy(
            customStreamUrl = link?.streamUrl,
            customPdfUrl = link?.pdfUrl
        )
    }

    suspend fun getSeriesDetail(seriesId: Long): MediaItem {
        val series = tmdbApi.getSeriesDetail(seriesId, TMDB_API_KEY)
        val link = customLinkDao.getLink("tmdb_tv_$seriesId")
        return series.toMediaItem().copy(
            customStreamUrl = link?.streamUrl,
            customPdfUrl = link?.pdfUrl
        )
    }

    suspend fun searchTmdb(query: String, page: Int = 1): List<MediaItem> {
        val response = tmdbApi.search(TMDB_API_KEY, query, page = page)
        return response.results.map { it.toMediaItem() }
    }

    // ==================== Jikan — Anime & Manga ====================

    suspend fun searchAnime(query: String, page: Int = 1): List<MediaItem> {
        val response = jikanApi.getAnimeSearch(query, page)
        return response.data.map { it.toMediaItem() }
    }

    suspend fun getTopAnime(page: Int = 1, type: String? = null): List<MediaItem> {
        val response = jikanApi.getTopAnime(page = page, type = type)
        return response.data.map { it.toMediaItem() }
    }

    suspend fun getCurrentSeasonAnime(page: Int = 1): List<MediaItem> {
        val response = jikanApi.getCurrentSeason(page)
        return response.data.map { it.toMediaItem() }
    }

    suspend fun getAnimeDetail(malId: Long): MediaItem {
        val response = jikanApi.getAnimeDetail(malId)
        val anime = response.data.first()
        val link = customLinkDao.getLink("jikan_$malId")
        return anime.toMediaItem().copy(
            customStreamUrl = link?.streamUrl,
            customPdfUrl = link?.pdfUrl
        )
    }

    suspend fun searchMangaJikan(query: String, page: Int = 1): List<MediaItem> {
        val response = jikanApi.getMangaSearch(query, page)
        return response.data.map { it.toMediaItem() }
    }

    suspend fun getTopManga(page: Int = 1): List<MediaItem> {
        val response = jikanApi.getTopManga(page = page)
        return response.data.map { it.toMediaItem() }
    }

    suspend fun getTopManhwa(page: Int = 1): List<MediaItem> {
        val response = jikanApi.getTopManhwa(page = page)
        return response.data.map { it.toMediaItem() }
    }

    // ==================== AniList — Anime, Manga, Manhwa ====================

    suspend fun searchAnimeAniList(query: String, page: Int = 1): List<MediaItem> {
        val pageData = aniListClient.searchAnime(query, page) ?: return emptyList()
        return pageData.media.map { it.toMediaItem() }
    }

    suspend fun searchMangaAniList(query: String, page: Int = 1): List<MediaItem> {
        val pageData = aniListClient.searchManga(query, page) ?: return emptyList()
        return pageData.media.map { it.toMediaItem() }
    }

    suspend fun getTrendingAnime(page: Int = 1): List<MediaItem> {
        val pageData = aniListClient.getTrendingAnime(page) ?: return emptyList()
        return pageData.media.map { it.toMediaItem() }
    }

    suspend fun getTrendingManga(page: Int = 1): List<MediaItem> {
        val pageData = aniListClient.getTrendingManga(page) ?: return emptyList()
        return pageData.media.map { it.toMediaItem() }
    }

    suspend fun getPopularManhwaAniList(page: Int = 1): List<MediaItem> {
        val pageData = aniListClient.getPopularManhwa(page) ?: return emptyList()
        return pageData.media.map { it.toMediaItem() }
    }

    // ==================== MangaDex — Manga & Manhwa ====================

    suspend fun searchMangaDex(query: String, offset: Int = 0): List<MediaItem> {
        val response = mangaDexApi.searchManga(query, offset = offset)
        return response.data.map { it.toMediaItem() }
    }

    suspend fun getMangaDexList(offset: Int = 0, originalLanguage: List<String>? = null): List<MediaItem> {
        val response = mangaDexApi.getMangaList(offset = offset, originalLanguage = originalLanguage)
        return response.data.map { it.toMediaItem() }
    }

    suspend fun getMangaDexDetail(mangaId: String): MediaItem? {
        val response = mangaDexApi.getMangaDetail(mangaId)
        val manga = response.data.firstOrNull() ?: return null
        val link = customLinkDao.getLink("mangadex_$mangaId")
        return manga.toMediaItem().copy(
            customPdfUrl = link?.pdfUrl,
            customStreamUrl = link?.streamUrl
        )
    }

    // ==================== ShineiAPI — Manga & Manhwa ====================

    suspend fun searchShinei(query: String): List<MediaItem> {
        val response = shineiApi.search(query)
        return response.data.map { it.toMediaItem() }
    }

    suspend fun getPopularShinei(type: String? = null): List<MediaItem> {
        val response = shineiApi.getPopular(type)
        return response.data.map { it.toMediaItem() }
    }

    // ==================== Search all ====================

    suspend fun searchAll(query: String): List<MediaItem> {
        val results = mutableListOf<MediaItem>()
        try { results.addAll(searchTmdb(query)) } catch (_: Exception) {}
        try { results.addAll(searchAnime(query)) } catch (_: Exception) {}
        try { results.addAll(searchAnimeAniList(query)) } catch (_: Exception) {}
        try { results.addAll(searchMangaJikan(query)) } catch (_: Exception) {}
        try { results.addAll(searchMangaDex(query)) } catch (_: Exception) {}
        try { results.addAll(searchShinei(query)) } catch (_: Exception) {}
        return results
    }

    // ==================== Custom Links ====================

    suspend fun setStreamUrl(mediaId: String, url: String) {
        customLinkDao.upsertLink(CustomLink(mediaId = mediaId, streamUrl = url))
    }

    suspend fun setPdfUrl(mediaId: String, url: String) {
        customLinkDao.upsertLink(CustomLink(mediaId = mediaId, pdfUrl = url))
    }

    suspend fun getCustomLink(mediaId: String): CustomLink? = customLinkDao.getLink(mediaId)

    // ==================== Bookmarks ====================

    fun getBookmarks(): Flow<List<Bookmark>> = bookmarkDao.getAllBookmarks()

    suspend fun toggleBookmark(item: MediaItem) {
        val exists = bookmarkDao.isBookmarked(item.id)
        if (exists) {
            bookmarkDao.removeBookmark(item.id)
        } else {
            bookmarkDao.addBookmark(
                Bookmark(
                    mediaId = item.id,
                    title = item.title,
                    posterUrl = item.posterUrl,
                    mediaType = item.type.name
                )
            )
        }
    }

    suspend fun isBookmarked(mediaId: String): Boolean = bookmarkDao.isBookmarked(mediaId)

    // ==================== Mapper Extensions ====================

    private fun TmdbMedia.toMediaItem(): MediaItem {
        val mediaType = when {
            mediaType == "movie" || title != null -> MediaType.MOVIE
            mediaType == "tv" || name != null -> MediaType.SERIES
            else -> MediaType.MOVIE
        }
        val prefix = if (mediaType == MediaType.MOVIE) "tmdb_movie_" else "tmdb_tv_"
        return MediaItem(
            id = "$prefix$id",
            source = MediaSource.TMDB,
            title = title ?: name ?: "Unknown",
            type = mediaType,
            posterUrl = if (posterPath != null) "${TMDB_IMAGE_BASE}w500$posterPath" else null,
            backdropUrl = if (backdropPath != null) "${TMDB_IMAGE_BASE}w780$backdropPath" else null,
            description = overview,
            rating = voteAverage,
            genres = genres?.map { it.name } ?: emptyList(),
            status = status,
            year = (releaseDate ?: firstAirDate)?.substringBefore("-")?.toIntOrNull(),
            episodes = numberOfEpisodes,
            duration = runtime ?: episodeRuntime?.firstOrNull(),
            studios = productionCompanies?.map { it.name } ?: emptyList()
        )
    }

    private fun JikanAnime.toMediaItem(): MediaItem {
        return MediaItem(
            id = "jikan_$malId",
            source = MediaSource.JIKAN,
            title = title,
            titleEnglish = titleEnglish,
            titleNative = titleJapanese,
            type = MediaType.ANIME,
            format = type,
            posterUrl = images.webp?.largeImageUrl ?: images.jpg.largeImageUrl ?: images.jpg.imageUrl,
            description = synopsis,
            rating = score,
            genres = genres?.map { it.name } ?: emptyList(),
            status = status,
            episodes = episodes,
            duration = duration?.replace(" min", "")?.toIntOrNull(),
            studios = studios?.map { it.name } ?: emptyList(),
            trailerUrl = trailer?.url,
            year = aired?.from?.substringBefore("-")?.toIntOrNull()
        )
    }

    private fun JikanManga.toMediaItem(): MediaItem {
        val mediaType = when (type?.lowercase()) {
            "manhwa" -> MediaType.MANHWA
            "manhua" -> MediaType.MANHWA
            else -> MediaType.MANGA
        }
        return MediaItem(
            id = "jikan_$malId",
            source = MediaSource.JIKAN,
            title = title,
            titleEnglish = titleEnglish,
            type = mediaType,
            format = type,
            posterUrl = images.webp?.largeImageUrl ?: images.jpg.largeImageUrl ?: images.jpg.imageUrl,
            description = synopsis,
            rating = score,
            genres = genres?.map { it.name } ?: emptyList(),
            status = status,
            chapters = chapters,
            authors = authors?.map { it.name } ?: emptyList()
        )
    }

    private fun AniListMedia.toMediaItem(): MediaItem {
        val mediaType = when (type) {
            "ANIME" -> MediaType.ANIME
            "MANGA" -> when {
                countryOfOrigin == "KR" -> MediaType.MANHWA
                countryOfOrigin == "CN" -> MediaType.MANHWA
                else -> MediaType.MANGA
            }
            else -> MediaType.ANIME
        }
        return MediaItem(
            id = "anilist_$id",
            source = MediaSource.ANILIST,
            title = title?.romaji ?: title?.english ?: "Unknown",
            titleEnglish = title?.english,
            titleNative = title?.native,
            type = mediaType,
            format = format,
            posterUrl = coverImage?.large ?: coverImage?.extraLarge,
            backdropUrl = bannerImage,
            coverUrl = coverImage?.extraLarge,
            description = description,
            rating = averageScore?.div(10.0),
            genres = genres ?: emptyList(),
            status = status,
            year = startDate?.year,
            episodes = episodes,
            chapters = chapters,
            duration = duration,
            country = countryOfOrigin,
            trailerUrl = trailer?.let { if (it.site == "youtube") "https://www.youtube.com/watch?v=${it.id}" else null },
            studios = studios?.nodes?.map { it.name } ?: emptyList()
        )
    }

    private fun MangaDexManga.toMediaItem(): MediaItem {
        val title = attributes.title?.values?.firstOrNull { it != null } ?: "Unknown"
        val description = attributes.description?.values?.firstOrNull { it != null }
        val mediaType = if (attributes.originalLanguage == "ko") MediaType.MANHWA else MediaType.MANGA
        // Extract cover file
        val coverRel = relationships?.find { it.type == "cover_art" }
        val coverFileName = coverRel?.attributes?.get("fileName") as? String
        val coverUrl = if (coverFileName != null) {
            "${MANGADEX_COVER_BASE}$id/$coverFileName"
        } else null

        return MediaItem(
            id = "mangadex_$id",
            source = MediaSource.MANGADEX,
            title = title,
            type = mediaType,
            posterUrl = coverUrl,
            coverUrl = coverUrl,
            description = description,
            status = attributes.status,
            year = attributes.year,
            genres = attributes.tags?.mapNotNull { it.attributes.name?.values?.firstOrNull() } ?: emptyList(),
            country = attributes.originalLanguage?.uppercase(),
            mangaDexId = id,
            coverFileName = coverFileName
        )
    }

    private fun ShineiSeries.toMediaItem(): MediaItem {
        val slug = title.lowercase().replace(" ", "-")
        val mediaType = when (type?.lowercase()) {
            "manhwa" -> MediaType.MANHWA
            "manga" -> MediaType.MANGA
            else -> MediaType.MANHWA
        }
        return MediaItem(
            id = "shinei_$slug",
            source = MediaSource.SHINEI,
            title = title,
            type = mediaType,
            posterUrl = coverUrl,
            coverUrl = coverUrl,
            description = description,
            rating = rating,
            genres = genres ?: emptyList(),
            status = status,
            chapters = chapters?.size,
            shineiSlug = slug
        )
    }
}
