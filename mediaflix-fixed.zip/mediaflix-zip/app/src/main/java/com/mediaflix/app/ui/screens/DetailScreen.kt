package com.mediaflix.app.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import coil.compose.AsyncImage
import com.mediaflix.app.data.model.MediaItem
import com.mediaflix.app.data.model.MediaType
import com.mediaflix.app.ui.components.MediaCard
import com.mediaflix.app.viewmodel.DetailViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(
    navController: NavHostController,
    mediaId: String,
    viewModel: DetailViewModel = hiltViewModel()
) {
    val details by viewModel.details.collectAsState()
    val streamUrl by viewModel.streamUrl.collectAsState()
    val pdfUrl by viewModel.pdfUrl.collectAsState()
    val isBookmarked by viewModel.isBookmarked.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val context = LocalContext.current

    LaunchedEffect(mediaId) {
        viewModel.loadDetails(mediaId)
    }

    // Add/Edit link dialog
    var showStreamDialog by remember { mutableStateOf(false) }
    var showPdfDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        if (isLoading) {
            Box(Modifier.fillMaxSize().padding(64.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            return@Column
        }

        val item = details ?: return@Column

        // Backdrop + Gradient
        Box(modifier = Modifier.fillMaxWidth().height(320.dp)) {
            val imageUrl = item.backdropUrl ?: item.posterUrl ?: item.coverUrl
            if (imageUrl != null) {
                AsyncImage(
                    model = imageUrl,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color.Transparent, Color.Transparent, MaterialTheme.colorScheme.background)
                        )
                    )
            )

            // Back button
            IconButton(
                onClick = { navController.popBackStack() },
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(16.dp)
                    .statusBarsPadding()
            ) {
                Icon(Icons.Filled.ArrowBack, "بازگشت", tint = Color.White, modifier = Modifier.size(28.dp))
            }
        }

        Spacer(Modifier.height((-60).dp))

        // Content
        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
            // Title + Bookmark
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = item.title,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = { viewModel.toggleBookmark() }) {
                    Icon(
                        if (isBookmarked) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                        contentDescription = "ذخیره",
                        tint = if (isBookmarked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            // Subtitle
            if (item.titleEnglish != null && item.titleEnglish != item.title) {
                Text(
                    text = item.titleEnglish,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(Modifier.height(12.dp))

            // Meta info row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                if (item.rating != null) {
                    InfoChip("⭐ ${String.format("%.1f", item.rating)}")
                }
                if (item.year != null) {
                    InfoChip("📅 ${item.year}")
                }
                item.format?.let { InfoChip("🎬 $it") }
                when (item.type) {
                    MediaType.MOVIE -> item.duration?.let { InfoChip("⏱ ${it}min") }
                    MediaType.SERIES -> item.episodes?.let { InfoChip("📺 ${it} قسمت") }
                    MediaType.ANIME -> item.episodes?.let { InfoChip("📺 ${it} قسمت") }
                    MediaType.MANGA, MediaType.MANHWA -> item.chapters?.let { InfoChip("📖 ${it} چپتر") }
                }
            }

            Spacer(Modifier.height(12.dp))

            // Genres
            if (item.genres.isNotEmpty()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item.genres.take(6).forEach { genre ->
                        Surface(
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = genre,
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(20.dp))

            // ===== Action Buttons =====
            // Stream button
            if (streamUrl != null) {
                Button(
                    onClick = { navController.navigate("player/$mediaId") },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Filled.PlayArrow, null)
                    Spacer(Modifier.width(8.dp))
                    Text("پخش آنلاین", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            } else {
                OutlinedButton(
                    onClick = { showStreamDialog = true },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Filled.AddLink, null)
                    Spacer(Modifier.width(8.dp))
                    Text("افزودن لینک استریم")
                }
            }

            Spacer(Modifier.height(8.dp))

            // PDF button (for manga/manhwa)
            if (item.type == MediaType.MANGA || item.type == MediaType.MANHWA) {
                if (pdfUrl != null) {
                    Button(
                        onClick = { navController.navigate("pdf/$mediaId") },
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Filled.PictureAsPdf, null)
                        Spacer(Modifier.width(8.dp))
                        Text("مشاهده PDF", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                } else {
                    OutlinedButton(
                        onClick = { showPdfDialog = true },
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Filled.PictureAsPdf, null)
                        Spacer(Modifier.width(8.dp))
                        Text("افزودن لینک PDF")
                    }
                }
            }

            Spacer(Modifier.height(20.dp))

            // Description
            if (!item.description.isNullOrBlank()) {
                Text(
                    text = "خلاصه داستان",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    text = item.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 22.sp
                )
            }

            Spacer(Modifier.height(20.dp))

            // Studios / Authors
            if (item.studios.isNotEmpty()) {
                Text("استودیو:", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                Text(item.studios.joinToString("، "), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (item.authors.isNotEmpty()) {
                Text("نویسنده:", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                Text(item.authors.joinToString("، "), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            Spacer(Modifier.height(16.dp))

            // Status
            item.status?.let {
                Text("وضعیت: $it", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
            }

            Spacer(Modifier.height(24.dp))
        }
    }

    // ===== Dialogs =====
    if (showStreamDialog) {
        LinkInputDialog(
            title = "افزودن لینک استریم",
            placeholder = "https://example.com/video.mp4",
            onDismiss = { showStreamDialog = false },
            onConfirm = { url ->
                viewModel.setStreamUrl(url)
                showStreamDialog = false
                Toast.makeText(context, "لینک استریم ذخیره شد ✅", Toast.LENGTH_SHORT).show()
            }
        )
    }

    if (showPdfDialog) {
        LinkInputDialog(
            title = "افزودن لینک PDF",
            placeholder = "https://example.com/manga.pdf",
            onDismiss = { showPdfDialog = false },
            onConfirm = { url ->
                viewModel.setPdfUrl(url)
                showPdfDialog = false
                Toast.makeText(context, "لینک PDF ذخیره شد ✅", Toast.LENGTH_SHORT).show()
            }
        )
    }
}

@Composable
fun InfoChip(text: String) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(8.dp)
    ) {
        Text(
            text = text,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun LinkInputDialog(
    title: String,
    placeholder: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var url by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = url,
                onValueChange = { url = it },
                placeholder = { Text(placeholder) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            TextButton(
                onClick = { if (url.isNotBlank()) onConfirm(url.trim()) },
                enabled = url.isNotBlank()
            ) { Text("ذخیره") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("انصراف") }
        }
    )
}
